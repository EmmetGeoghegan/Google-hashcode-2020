list = [1,2,3]
sorted_libos = sorted(list, key=lambda x: -x)
print(sorted_libos)
