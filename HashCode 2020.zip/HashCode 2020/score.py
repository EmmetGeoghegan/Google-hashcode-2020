def scoring_function():
        score = 0
        already_scanned = []
        for book_self in all_books):
            if book_self.shipped == True:
                score += book_self.scores
        return score
